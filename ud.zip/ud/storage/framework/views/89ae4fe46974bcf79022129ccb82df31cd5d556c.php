<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Express Mail</title></head><body>
<table style='width: 100%;'>
<thead style='text-align: center;'><tr><td style='border:none;' colspan='2'>
<table class='es-wrapper' width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;padding:0;Margin:0;width:100%;height:100%;background-repeat:repeat;background-position:center top;background-color:#FAFAFA'>
                <tr>
                    <td valign='top' style='padding:0;Margin:0'>
                        <table class='es-content' cellspacing='0' cellpadding='0' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%'>
                            <tr>
                                <td align='center' style='padding:0;Margin:0'>
                                    <table class='es-content-body' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px' cellspacing='0' cellpadding='0' bgcolor='#FFFFFF' align='center'>
                                        <tr>
                                            <td align='left' style='padding:20px;Margin:0'>
                                                <table width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                    <tr>
                                                        <td valign='top' align='center' style='padding:0;Margin:0;width:560px'>
                                                            <table width='100%' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                <tr>

                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table>
                        <table class='es-header' cellspacing='0' cellpadding='0' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top'>
                            <tr>
                                <td align='center' style='padding:0;Margin:0'>
                                    <table class='es-header-body' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px'>
                                        <tr>
                                            <td align='left' style='padding:20px;Margin:0'>
                                                <table width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                    <tr>
                                                        <td class='es-m-p0r' valign='top' align='center' style='padding:0;Margin:0;width:560px'>
                                                            <table width='100%' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                <tr>
                                                                    <td style='padding:0;Margin:0;padding-bottom:20px;font-size:0px' align='center'><img  src='https://mobile.primedata.com.ng/images/bn.jpeg' alt='Logo' style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;font-size:12px' title='Logo' width='150' height='150'></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table>
                        <table class='es-content' cellspacing='0' cellpadding='0' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%'>
                            <tr>
                                <td align='center' style='padding:0;Margin:0'>
                                    <table class='es-content-body' cellspacing='0' cellpadding='0' bgcolor='#ffffff' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#FFFFFF;width:600px'>
                                        <tr>
                                            <td align='left' style='padding:0;Margin:0;padding-top:20px;padding-left:20px;padding-right:20px'>
                                                <table width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                    <tr>
                                                        <td align='left' style='padding:0;Margin:0;width:560px'>
                                                            <table width='100%' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                <tr>
                                                                    <td align='center' style='padding:0;Margin:0;padding-bottom:10px;padding-top:20px'><h1 style='Margin:0;line-height:46px;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;font-size:46px;font-style:normal;font-weight:bold;color:#333333'>Transactional Email<br></h1></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                        <tr>
                                            <td align='left' style='padding:20px;Margin:0'>
                                                <!--[if mso]><table style='width:560px' cellpadding='0' cellspacing='0'><tr><td style='width:60px' valign='top'><![endif]-->
                                                <table class='es-left' cellspacing='0' cellpadding='0' align='left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                                    <tr>
                                                        <td align='left' style='padding:0;Margin:0;width:60px'>
                                                            <table width='100%' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                <tr>

                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table>
                                                <!--[if mso]></td><td style='width:10px'></td><td style='width:490px' valign='top'><![endif]-->
                                                <table class='es-right' cellspacing='0' cellpadding='0' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                                    <tr>
                                                        <td align='left' style='padding:0;Margin:0;width:490px'>
                                                            <table width='100%' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                <tr>
                                                                    <td class='es-m-txt-c' align='left' style='padding:0;Margin:0'><h3 style='Margin:0;line-height:40px;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;font-size:20px;font-style:normal;font-weight:bold;color:#666666'>
                                                                            <?php echo e(Auth::user()->name); ?></h3><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;line-height:21px;color:#666666;font-size:14px'></p></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table>
                                        </tr>
                                        <tr>
                                            <td align='left' style='padding:0;Margin:0;padding-bottom:20px;padding-left:20px;padding-right:20px'>
                                                <table width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                    <tr>
                                                        <td valign='top' align='center' style='padding:0;Margin:0;width:560px'>
                                                            <table style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-image:url(https://rszomp.stripocdn.email/content/guids/CABINET_6e43b4f07bc0bea4fe2d66ad7614e6c5/images/98461632176534242.jpg);background-repeat:no-repeat;background-position:left top' width='100%' cellspacing='0' cellpadding='0' background='https://rszomp.stripocdn.email/content/guids/CABINET_6e43b4f07bc0bea4fe2d66ad7614e6c5/images/98461632176534242.jpg' role='presentation'>
                                                                <tr>
                                                                    <td align='left' style='padding:0;Margin:0;padding-top:15px'><?php echo e($bo['plan']); ?><br></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align='left' style='padding:0;Margin:0;padding-top:5px;padding-bottom:10px'><span>Dear&nbsp;</span><strong><?php echo e($bo['username']); ?></strong><span>,</span><br><span>A payment was successfully completed on your account.</span><br><span>Please see below details of the transaction:</span>
                                                                        <ul>
                                                                            <li style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;line-height:21px;Margin-bottom:15px;color:#333333;font-size:14px'>Phone No:<strong><?php echo e($bo['phone']); ?></strong></li>

                                                                            <li style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;line-height:21px;Margin-bottom:15px;color:#333333;font-size:14px'>Details:<strong> <?php echo e($bo['plan']); ?>-<?php echo e($bo['amount']); ?></strong></li>
                                                                            <li style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;line-height:21px;Margin-bottom:15px;color:#333333;font-size:14px'>Payment Method: <strong>Wallet</strong></li>
                                                                            <li style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;line-height:21px;Margin-bottom:15px;color:#333333;font-size:14px'>Reference Number: <strong><?php echo e($bo['refid']); ?></strong></li>


                                                                        </ul><br></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table>
                        <table class='es-footer' cellspacing='0' cellpadding='0' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top'>
                            <tr>
                                <td align='center' style='padding:0;Margin:0'>
                                    <table class='es-footer-body' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                            <td align='left' style='Margin:0;padding-top:20px;padding-bottom:20px;padding-left:20px;padding-right:20px'>
                                                <table width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                    <tr>
                                                        <td align='left' style='padding:0;Margin:0;width:560px'>
                                                            <table width='100%' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                <tr>
                                                                    <td style='padding:0;Margin:0;padding-top:15px;padding-bottom:15px;font-size:0' align='center'>
                                                                        <table class='es-table-not-adapt es-social' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                            <tr>
                                                                                <td valign='top' align='center' style='padding:0;Margin:0;padding-right:40px'><img title='Facebook' src='https://rszomp.stripocdn.email/content/assets/img/social-icons/logo-black/facebook-logo-black.png' alt='Fb' width='32' height='32' style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic'></td>
                                                                                <td valign='top' align='center' style='padding:0;Margin:0;padding-right:40px'><img title='Twitter' src='https://rszomp.stripocdn.email/content/assets/img/social-icons/logo-black/twitter-logo-black.png' alt='Tw' width='32' height='32' style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic'></td>
                                                                                <td valign='top' align='center' style='padding:0;Margin:0;padding-right:40px'><img title='Instagram' src='https://rszomp.stripocdn.email/content/assets/img/social-icons/logo-black/instagram-logo-black.png' alt='Inst' width='32' height='32' style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic'></td>
                                                                                <td valign='top' align='center' style='padding:0;Margin:0'><img title='Youtube' src='https://rszomp.stripocdn.email/content/assets/img/social-icons/logo-black/youtube-logo-black.png' alt='Yt' width='32' height='32' style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic'></td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align='center' style='padding:0;Margin:0;padding-bottom:35px'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;line-height:18px;color:#333333;font-size:12px'></p><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, helvetica neue, helvetica, sans-serif;line-height:18px;color:#333333;font-size:12px'>If you have any questions/issues, please contact us at&nbsp;<a href='mailto:info@5starcompany.com.ng' target='_blank' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#333333;font-size:12px'></a>primedata18@gmail.com<br>Thanks for choosing us<br></p></td>
                                                                </tr>
                                                                <tr>
                                                                    <td style='padding:0;Margin:0'>
                                                                        <table class='es-menu' width='100%' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                            <tr class='links'>
                                                                                <td style='Margin:0;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;border:0' width='33.33%' valign='top' align='center'><a target='_blank' href='' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;display:block;font-family:arial, 'helvetica neue', helvetica, sans-serif;color:#999999;font-size:12px'>Visit Us </a></td>
                                                                                <td style='Margin:0;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;border:0;border-left:1px solid #cccccc' width='33.33%' valign='top' align='center'><a target='_blank' href='' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;display:block;font-family:arial, 'helvetica neue', helvetica, sans-serif;color:#999999;font-size:12px'>Privacy Policy</a></td>
                                                                                <td style='Margin:0;padding-left:5px;padding-right:5px;padding-top:5px;padding-bottom:5px;border:0;border-left:1px solid #cccccc' width='33.33%' valign='top' align='center'><a target='_blank' href='' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;display:block;font-family:arial, 'helvetica neue', helvetica, sans-serif;color:#999999;font-size:12px'>Terms of Use</a></td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table>
                        <table class='es-content' cellspacing='0' cellpadding='0' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%'>
                            <tr>
                                <td align='center' style='padding:0;Margin:0'>
                                    <table class='es-content-body' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px' cellspacing='0' cellpadding='0' bgcolor='#FFFFFF' align='center'>
                                        <tr>
                                            <td align='left' style='padding:20px;Margin:0'>
                                                <table width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                    <tr>
                                                        <td valign='top' align='center' style='padding:0;Margin:0;width:560px'>
                                                            <table width='100%' cellspacing='0' cellpadding='0' role='presentation' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                                <tr>
                                                                    <td class='es-infoblock' align='center' style='padding:0;Margin:0;line-height:14px;font-size:12px;color:#CCCCCC'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;line-height:14px;color:#CCCCCC;font-size:12px'><a target='_blank' href='' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#CCCCCC;font-size:12px'></a>No longer want to receive these emails?&nbsp;<a href='' target='_blank' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#CCCCCC;font-size:12px'>Unsubscribe</a>.<a target='_blank' href='' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#CCCCCC;font-size:12px'></a></p></td>
                                                                </tr>
                                                            </table></td>
                                                    </tr>
                                                </table></td>
                                        </tr>
                                    </table></td>
                            </tr>
                        </table></td>
                </tr>
</table>
<?php /**PATH C:\xampp\htdocs\up\ud\resources\views/email/tran.blade.php ENDPATH**/ ?>
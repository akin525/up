<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <!--    <div class="card">-->
    <div class="card-body">
        <div class="module-head">
            <h3>
                Buy Data</h3>
        </div>
        <center>
            <div class="btn-controls">
                <form action="<?php echo e(route('pre')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="network" class=" requiredField">
                        Choose Network<span class="asteriskField">*</span>
                    </label>
                    <select  name="id" class="text-success form-control" required="">
                        <option value="">---------</option>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user->apikey=""): ?>
                            <option value="<?php echo e($datas->id); ?>"><?php echo e($datas->network); ?><?php echo e($datas->plan); ?><?php echo e($datas->tamount); ?>

                                <?php else: ?>
                                <option value="<?php echo e($datas->id); ?>"><?php echo e($datas->network); ?><?php echo e($datas->plan); ?><?php echo e($datas->ramount); ?>

                                    <?php endif; ?>
                                </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                    <button type="submit" class=" btn" style="color: white;background-color: #095b0d"> Next</button>
                </form>
        </center>
        <h4 class="btn-info">
            <ul class="list-group">
                <li class="list-group-item list-group-item-success">MTN [SME]     *461*4#  </li>
                <li class="list-group-item list-group-item-primary">MTN [Gifting]     *131*4# or *460*260#  </li>
                <li class="list-group-item list-group-item-dark"> 9mobile [Gifting]   *228# </li>
                <li class="list-group-item list-group-item-danger"> Airtel   *140# </li>
                <li class="list-group-item list-group-item-success"> Glo  *127*0#. </li>
            </ul>

        </h4>
        <br>
        <style>
            img {
                max-width: 100%;
                height: auto;
            }
        </style>
        <div class="card-body">
            <div class="center">
                <img    src="<?php echo e(asset('images/re.jpg')); ?>" alt="#" />
            </div>
        </div>

        <br>
    </div>
</div>
</div>
</center>
<?php /**PATH C:\xampp\htdocs\up\ud\resources\views/buydata.blade.php ENDPATH**/ ?>
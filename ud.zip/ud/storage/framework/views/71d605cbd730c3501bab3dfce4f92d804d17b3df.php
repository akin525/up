<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="span9">
    <div class="content">
        <div class="module">
            <div class="module-head">
                <h3>
                    Preview Data</h3>
            </div>
            <center>
                <div class="card">
                    <div class="card-body">
                        <div class="row page-breadcrumbs">
                            <div class="col-md-12 align-self-center">

                                <h4 class="theme-cl">Product Detail</h4>
                            </div>
                        </div>
                    </div>
                    <?php if(isset($mg)): ?>
                        <div class='alert alert-success'>
                            <button type='button' class='close' data-dismiss='alert'>&times;</button>
                            <i class='fa fa-ban-circle'></i><strong>Notification: </br></strong><b class='align-content-center'><?php echo e($mg); ?></b>
                        </div>
                    <?php endif; ?>

                    
                    


                    
                    

                    

                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    

                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    

                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box">
                                <div class="box-body">
                                    <div class="card-body">
                                        <label for="network" class=" requiredField">
                                            Product<span class="asteriskField">*</span>
                                        </label>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="text" class="form-control text-success" value="<?php echo e($data1->network); ?>..<?php echo e($data1->plan); ?>" readonly/>


                                            <input type="hidden" class="form-control text-success" value="" readonly/>


                                            <?php if(!($data1->plan_id=="airtime")): ?>
                                                <label for="network" class="text-primary requiredField">
                                                    Amount<span class="asteriskField">*</span>
                                                </label>
                                                <input type="text" class="form-control text-primary" value="NGN<?php echo e($data1->tamount); ?>" readonly/>
                                            <?php endif; ?>

                                            <form action="<?php echo e(route('bill')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php if($user->apikey=""): ?>
                                                <input type="hidden" name="amount" value="<?php echo e($data1->tamount); ?>">
                                                <?php else: ?>
                                                    <input type="hidden" name="amount" value="<?php echo e($data1['ramount']); ?>">
                                                <?php endif; ?>
                                                    <input type="hidden" name="name" value="<?php echo e($data1->network); ?>..<?php echo e($data1->plan); ?>">
                                                <input type="hidden" name="productid" value="<?php echo e($data1->id); ?>">
                                                <input type="hidden" name="id" value="<?php echo rand(10000000, 999999999); ?>">

                                                <?php if($data1->plan_id=="airtime"): ?>
                                                    <div class="form-group">
                                                        <label for="network" class="text-success requiredField">
                                                            Enter Amount<span class="asteriskField">*</span>
                                                        </label>
                                                        <input class="form-control text-primary" type="number" placeholder="Enter Amount" maxlength="4" minlength="3" id="amount" name="amount" value="" autocomplete="on" size="20" min="100" max="4000" required="">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="network" class="text-success requiredField">
                                                            Enter Phone No<span class="asteriskField">*</span>
                                                        </label>
                                                        <input class="form-control text-success" type="tel" placeholder="Enter recipient number" maxlength="11" minlength="11" id="phone" name="number" value="" autocomplete="on" size="20" required="">
                                                    </div>
                                                    <button type="submit" class="btn btn-rounded btn-outline-info"> Continue </button>

                                                <?php else: ?>
                                                    <input type="hidden" name="amount" value="<?php echo e($data1->tamount); ?>">
                                                <?php endif; ?>

                                            <!--                                            --><?php //if ($product_type=="tv") { ?>
                                                
                                                
                                                
                                                

                                                
                                                
                                                
                                                <?php if($data1->status==1): ?>
                                                    <div class="form-group">
                                                        <label for="network" class="text-successrequiredField">
                                                            Enter Phone No<span class="asteriskField">*</span>
                                                        </label>
                                                        <input class="form-control text-primary" type="tel" placeholder="Enter recipient number" maxlength="11" minlength="11" id="phone" name="number" value="" autocomplete="on" size="20" required="">
                                                    </div>

                                                    <button type="submit" class="btn btn-rounded btn-outline-info"> Continue </button>
                                                <?php endif; ?>

                                                

                                                
                                                
                                                
                                                
                                                
                                                
                                                

                                                
                                                

                                                
                                            </form>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <br>

                                        <h3 class="box-title mrg-top-30">Key Highlights</h3>

                                        <ul class="list-icons">
                                            <li><i class="fa fa-check text-success"></i> Secure Payment Gateways</li>
                                            <li><i class="fa fa-check text-success"></i> Instant Activation</li>
                                            <li><i class="fa fa-check text-success"></i> Efficient Performance</li>
                                        </ul>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>

                </div>
        </div>
    </div>
</div>
        <!--        <div class="col-sm-4 ">-->
        <!--            <br>-->
        <!--            <center> <h4>Codes for Data Balance: </h4></center>-->
        <!--            <ul class="list-group">-->
        <!--                <li class="list-group-item list-group-item-secondary">MTN [SME]     *461*4#  </li>-->
        <!--                <li class="list-group-item list-group-item-primary">MTN [Gifting]     *131*4# or *460*260#  </li>-->
        <!--                <li class="list-group-item list-group-item-dark"> 9mobile [Gifting]   *228# </li>-->
        <!--                <li class="list-group-item list-group-item-action"> Airtel   *140# </li>-->
        <!--                <li class="list-group-item list-group-item-success"> Glo  *127*0#. </li>-->
        <!--            </ul>-->
        <!--            <br>-->
        <!--            <center> <h6>Codes for Airtime Balance: </h6></center>-->
        <!--            <ul class="list-group">-->
        <!--                <li class="list-group-item list-group-item-primary">MTN Airtime VTU    <span id="RightT"> *556#  </span></li>-->
        <!---->
        <!--                <li class="list-group-item list-group-item-success"> 9mobile Airtime VTU   *232# </li>-->
        <!--                <li class="list-group-item list-group-item-info"> Airtel Airtime VTU   *123# </li>-->
        <!--                <li class="list-group-item list-group-item-dark"> Glo Airtime VTU #124#. </li>-->
        <!--            </ul>-->
        <!--        </div>-->
        <!--    </div>-->
<?php /**PATH C:\xampp\htdocs\up\ud\resources\views/pre.blade.php ENDPATH**/ ?>
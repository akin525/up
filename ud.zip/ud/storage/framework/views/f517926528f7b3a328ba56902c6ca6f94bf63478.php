<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>User Dashboard</title>
    <meta name="keywords" content="Buy data in a few clicks to keep surfing the internet. You can buy whatever size of data plan for whichever network you desire. All plans are topped-up to your specified number in seconds.">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- site icon -->
    <link rel="icon" href="https://mobile.primedata.com.ng/images/bn.jpeg" type="image/png" />
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('asset/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('asset/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('asset/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
    <!-- site css -->
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>" />
    <!-- responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>" />
    <!-- color css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/colors.css')); ?>" />
    <!-- select bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.css')); ?>" />
    <!-- scrollbar css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/perfect-scrollbar.css')); ?>" />
    <!-- custom css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>" />
</head>

<body class="dashboard dashboard_1">
<div class="full_container">
    <div class="inner_container">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar_blog_1">
                <div class="sidebar-header">
                    <div class="logo_section">
                        <a href="#"><img class="logo_icon img-responsive" src="<?php echo e(asset("images/bn.jpeg")); ?>" alt="#" /></a>
                    </div>
                </div>
                <div class="sidebar_user_info">
                    <div class="icon_setting"></div>
                    <div class="user_profle_side">
                        <div class="user_img"><img class="img-responsive" src="<?php echo e(asset("images/layout_img/user_img.jpg")); ?>" alt="#" /></div>
                        <div class="user_info">
                            <h6> <?php echo e(Auth::user()->username); ?></h6>
                            <p><span class="online_animation"></span> Online</p>
                        </div>
                    </div>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" x-data>
                        <?php echo csrf_field(); ?>

                        <a href="<?php echo e(route('logout')); ?>"><button type="submit" class="btn btn-primary">logout</button></a>
                    </form>
                </div>

            </div>
            <div class="sidebar_blog_2">
                <h4>General</h4>
                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="<?php echo e(route('dashboard')); ?>"  ><i class="fa fa-dashboard yellow_color"></i> <span>Dashboard</span></a>
                    </li>
                    <?php if(Auth::user()->apikey ==NULL): ?>
                    <li>
                        <a href="<?php echo e(route('reseller')); ?>"><i class="fa fa-shopping-cart "></i> <span>Become Reseller</span></a>
                    </li>
                    <?php else: ?>
                        <li>
                            <a href="<?php echo e(route('upgrade')); ?>"><i class="fa fa-book "></i> <span>Api</span></a>
                        </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('referal')); ?>"><i class="fa fa-laptop "></i> <span>Referal System</span></a>
                    </li>
                    <li class="active">
                        <a href="<?php echo e(route('profile.show')); ?>"  ><i class="fa fa-user yellow_color"></i> <span>My Account</span></a>
                    </li>
                    <li><a href="<?php echo e(route('fund')); ?>"><i class="fa fa-credit-card orange_color"></i> <span>Fund Wallet</span></a></li>
                    <li>
                        <a href="<?php echo e(route('airtime')); ?>"><i class="fa fa-phone "></i> <span>Buy Airtime</span></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-tv"></i> <span>Pay Tv</span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('buydata')); ?>"><i class="fa fa-laptop "></i> <span>Buy Data</span></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-power-off"></i> <span>Pay Electricity</span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('invoice')); ?>"><i class="fa fa-sticky-note yellow_color"></i> <span>Bills Invoice</span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('charges')); ?>"><i class="fa fa-sticky-note"></i> <span>Charges</span></a>
                    </li>
                </ul>
            </div>
        </nav>
        <div id="content">
            <!-- topbar -->
            <div class="topbar">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <div class="full">
                        <button type="button" id="sidebarCollapse" class="sidebar_toggle"><i class="fa fa-bars"></i></button>
                        <div class="logo_section">
                            <a href="<?php echo e(route('dashboard')); ?>"><img class="img-responsive" src="<?php echo e(asset("images/bn.jpeg")); ?>" alt="#" /></a>
                        </div>























                    </div>
                </nav>
            </div>
            <!-- end topbar -->

















            <!-- jQuery -->
            <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
            <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
            <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
            <!-- wow animation -->
            <script src="<?php echo e(asset('js/animate.js')); ?>"></script>
            <!-- select country -->
            <script src="<?php echo e(asset('js/bootstrap-select.js')); ?>"></script>
            <!-- owl carousel -->
            <script src="<?php echo e(asset('js/owl.carousel.js')); ?>"></script>

            <!-- nice scrollbar -->
            <script src="<?php echo e(asset('js/perfect-scrollbar.min.js')); ?>"></script>
            <script>
                var ps = new PerfectScrollbar('#sidebar');
            </script>
            <!-- custom js -->
            <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
            <script src="<?php echo e(asset('js/chart_custom_style1.js')); ?>"></script>


            <!-- script -->

<?php /**PATH C:\xampp\htdocs\up\ud\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

        <link href="<?php echo e(asset('asset/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('asset/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('asset/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
        <!-- site css -->
        <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>" />
        <!-- responsive css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>" />
        <!-- color css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/colors.css')); ?>" />
        <!-- select bootstrap -->
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.css')); ?>" />
        <!-- scrollbar css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/perfect-scrollbar.css')); ?>" />
        <!-- custom css -->
        <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>" />

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    </head>



            <!-- Page Heading -->
<br>
    <br>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>


        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\up\ud\resources\views/layouts/app.blade.php ENDPATH**/ ?>
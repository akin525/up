<div class="logo_login">
    <div class="center">
        <img width="110" src="<?php echo e(asset("images/bn.jpeg")); ?>" alt="#" />
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\up\ud\vendor\laravel\jetstream\src/../resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>
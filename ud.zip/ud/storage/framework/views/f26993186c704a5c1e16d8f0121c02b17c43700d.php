<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(isset($mg)): ?>
    <script>alert('<?php echo e($mg); ?>');
        window.location='<?php echo e(route('dashboard')); ?>';
    </script>
<?php endif; ?>


<?php if(!isset($success)): ?>
    <script>alert('<?php echo e($mg); ?>');
        window.location='<?php echo e(route('dashboard')); ?>';
    </script>
<?php else: ?>
    <style>
        body {
            text-align: center;
            padding: 40px 0;
            background: #EBF0F5;
        }
        h1 {
            color: #88B04B;
            font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
            font-weight: 900;
            font-size: 40px;
            margin-bottom: 10px;
        }h2 {
             color: #fa0334;
             font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
             font-weight: 900;
             font-size: 40px;
             margin-bottom: 10px;
         }
        p {
            color: #404F5E;
            font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
            font-size:20px;
            margin: 0;
        }
        i {
            color: #9ABC66;
            font-size: 100px;
            line-height: 200px;
            margin-left:-15px;
        } f {
              color: #fa0334;
              font-size: 100px;
              line-height: 200px;
              margin-left:-15px;
          }
        .card {
            background: white;
            padding: 60px;
            border-radius: 4px;
            box-shadow: 0 2px 3px #C8D0D8;
            display: inline-block;
            margin: 0 auto;
        }
    </style>
    <body>
    <div class='card'>
        <?php if($success==1): ?>
            <div style='border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;'>
                <i class='checkmark'>✓</i>
            </div>
            <h1>Success</h1>
        <?php elseif($success==0): ?>
            <div style='border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;'>
                <f class='checkmark'>x</f>
            </div>
            <h2>Fail</h2>

        <?php endif; ?>

        <?php if(isset($am) && isset($ph)): ?>
            <p><?php echo e($am); ?> <?php echo e($ph); ?><br/> Thanks</p>
            <a href='<?php echo e(route('dashboard')); ?>'><button type='button' class='btn btn-outline-success'>Continue</button></a>
        <?php else: ?>
            <p>Dupllicate Transaction<br/> Thanks</p>
            <a href='<?php echo e(route('dashboard')); ?>'><button type='button' class='btn btn-outline-success'>Continue</button></a>
        <?php endif; ?>
    </div>

    </body>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\up\ud\resources\views/bill.blade.php ENDPATH**/ ?>